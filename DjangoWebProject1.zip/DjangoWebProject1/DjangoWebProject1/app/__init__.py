﻿"""
Package for the application.
"""
