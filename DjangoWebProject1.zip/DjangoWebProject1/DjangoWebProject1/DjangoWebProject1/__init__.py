﻿"""
Package for DjangoWebProject1.
"""
